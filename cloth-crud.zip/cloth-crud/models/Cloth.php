<?php 
    class Cloth{
        public $id, $name, $brand, $price, $stock, $image;
        private $db;

        public function __construct(){
            $this->db = new Database();
        }

        public function store(){
            $this->db->execute("INSERT INTO cloths (name, brand, price, stock, image) VALUES (:name, :brand, :price, :stock, :image);",
            [
                'name' => strval($this->name),
                'brand' => strval($this->brand),
                'price' => floatval($this->price),
                'stock' => intval($this->stock),
                'image' => strval($this->image)
            ]);
            
            return json_encode([
                'result' => true,
                'message' => 'Cloth added successfully',
            ]);
        }

        public function destroy(){
            $this->db->execute("DELETE FROM cloths WHERE id = :id;", ['id' => $this->id]);
            
            return json_encode([
                'result' => true,
                'message' => 'Cloth deleted successfully',
            ]);
        }

        public function update(){
            $this->db->execute("UPDATE cloths SET name = :name, brand = :brand, price = :price, stock = :stock, image = :image WHERE id = :id;",
            [
                'name' => strval($this->name),
                'brand' => strval($this->brand),
                'price' => floatval($this->price),
                'stock' => intval($this->stock),
                'image' => strval($this->image),
                'id' => intval($this->id)
            ]);
            
            return json_encode([
                'result' => true,
                'message' => 'Cloth updated successfully',
            ]);
        }

        public function index($name, $brand){
            $sql = "SELECT * FROM cloths";
            $params = [];
            
            if($name || $brand){
                $conditions = [];
                
                if($name){
                    $conditions[] = "name LIKE :name";
                    $params['name'] = $name . '%';
                }
                
                if($brand){
                    $conditions[] = "brand LIKE :brand";
                    $params['brand'] = $brand . '%';
                }
                
                $sql .= " WHERE " . implode(" OR ", $conditions); 
            }
            
            $cloths = $this->db->executeAssoc($sql, $params);
            
            return json_encode([
                'result' => true,
                'message' => 'Cloths retrieved successfully',
                'data' => $cloths,
            ]);
        }
    }
?>