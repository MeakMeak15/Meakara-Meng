<?php 
    define('DB_HOST','localhost');
    define('DB_NAME','db_php_crud_project');
    define('DB_PORT','3307');
    define('USERNAME','root');
    define('PASSWORD','root123')
?>