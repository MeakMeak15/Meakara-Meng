(() => {
  const formCloth = document.getElementById("form-cloth");
  const iClothName = document.getElementById("cloth-name");
  const iBrandName = document.getElementById("brand-name");
  const iPrice = document.getElementById("price");
  const iStock = document.getElementById("stock");
  const iImage = document.getElementById("image");
  const tableBody = document.getElementById("table-body");
  const totalPrice = document.getElementById("total-price");
  const buttonSubmit = document.getElementById("btn-submit");
  const searchText = document.getElementById("search-text");
  let cloths = [];
  let selectedID = 0;

  const formatCurrency = (value) => {
    return parseFloat(value).toLocaleString("en-US", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  };

  const loadCloths = () => {
    axios
      .get("/api/cloth/index.php")
      .then((res) => {
        if (res.data.result) {
          cloths = res.data.data || [];

          // Calculate total price if not provided by API
          let totalPriceValue = 0;
          cloths.forEach((cloth) => {
            totalPriceValue += parseFloat(cloth.price) * parseInt(cloth.stock);
          });

          totalPrice.innerHTML = `<h5 class="mb-0">Total Price: $${formatCurrency(
            totalPriceValue
          )}</h5>`;
          renderCloths(cloths);
        } else {
          tableBody.innerHTML =
            '<tr><td colspan="6" class="text-center">No cloths found</td></tr>';
          totalPrice.innerHTML = `<h5 class="mb-0">Total Price: $0.00</h5>`;
        }
      })
      .catch((error) => {
        console.error("Error loading cloths:", error);
        alert("Failed to load cloths. Please try again.");
      });
  };

  const renderCloths = (clothsToRender) => {
    tableBody.innerHTML = "";

    if (!clothsToRender || clothsToRender.length === 0) {
      tableBody.innerHTML =
        '<tr><td colspan="6" class="text-center">No cloths found</td></tr>';
      return;
    }

    clothsToRender.forEach((cloth) => {
      tableBody.innerHTML += `<tr>
                <td class="align-middle">
                    <div class="d-flex align-items-center gap-3">
                        <img src=${
                          cloth.image
                            ? `/storage/images/${cloth.image}`
                            : "/assets/img/default.png"
                        } 
                             class="rounded-circle object-fit-cover" 
                             style="width: 55px; height: 55px;" 
                             alt="${cloth.name}">
                        <p style="padding-top: 15px"><strong>${
                          cloth.name
                        }</strong></p>
                    </div>
                </td>
                <td class="align-middle">${cloth.brand}</td>
                <td class="align-middle">$${formatCurrency(cloth.price)}</td>
                <td class="align-middle">${cloth.stock}</td>
                <td class="align-middle">
                    <span class="stock-status ${
                      parseInt(cloth.stock) > 10
                        ? "in-stock"
                        : parseInt(cloth.stock) > 0
                        ? "low-stock"
                        : "out-of-stock"
                    }">
                        ${
                          parseInt(cloth.stock) > 10
                            ? "In Stock"
                            : parseInt(cloth.stock) > 0
                            ? "Low Stock"
                            : "Out of Stock"
                        }
                    </span>
                </td>
                <td class="align-middle">
                    <button data-cloth='${JSON.stringify(
                      cloth
                    )}' class="btn btn-warning edit-button">Edit</button>
                    <button data-id="${cloth.id}" data-name="${
        cloth.name
      }" class="btn btn-danger delete-button">Delete</button>
                </td>
            </tr>`;
    });

    // Attach event listeners to delete buttons
    document.querySelectorAll(".delete-button").forEach((btn) => {
      btn.onclick = () => {
        const selectedID = btn.getAttribute("data-id");
        const clothName = btn.getAttribute("data-name");

        if (confirm(`Are you sure you want to delete "${clothName}"?`)) {
          axios
            .get(`/api/cloth/destroy.php?id=${selectedID}`)
            .then((res) => {
              if (!res.data.result) {
                alert(res.data.message);
                return;
              }
              loadCloths();
            })
            .catch((error) => {
              console.error("Error deleting cloth:", error);
              alert("Failed to delete cloth. Please try again.");
            });
        }
      };
    });

    // Attach event listeners to edit buttons
    document.querySelectorAll(".edit-button").forEach((btn) => {
      btn.onclick = () => {
        try {
          const jsonCloth = btn.getAttribute("data-cloth");
          const cloth = JSON.parse(jsonCloth);

          // Update form with cloth details
          selectedID = cloth.id;
          iClothName.value = cloth.name;
          iBrandName.value = cloth.brand;
          iPrice.value = cloth.price;
          iStock.value = cloth.stock;

          // Change button text to indicate edit mode
          buttonSubmit.innerText = "Update Cloth";

          // Scroll to form
          formCloth.scrollIntoView({ behavior: "smooth" });
        } catch (e) {
          console.error("Error parsing cloth data:", e);
          alert("Error loading cloth details");
        }
      };
    });
  };

  const searchCloth = (searchValue) => {
    if (!searchValue || searchValue.trim() === "") {
      renderCloths(cloths);
      return;
    }

    const searchLower = searchValue.toLowerCase();
    const filteredCloths = cloths.filter(
      (cloth) =>
        cloth.name.toLowerCase().includes(searchLower) ||
        cloth.brand.toLowerCase().includes(searchLower)
    );

    renderCloths(filteredCloths);
  };

  // Search functionality
  searchText.addEventListener("input", (e) => {
    searchCloth(e.target.value);
  });

  const clearForm = () => {
    iClothName.value = "";
    iBrandName.value = "";
    iPrice.value = "";
    iStock.value = "";
    iImage.value = "";
    selectedID = 0;
    buttonSubmit.innerText = "Add Cloth";
  };

  // Reset button functionality
  const resetButton = document.getElementById("btn-reset");
  if (resetButton) {
    resetButton.addEventListener("click", (e) => {
      e.preventDefault();
      clearForm();
    });
  }

  // Load cloths when page loads
  loadCloths();

  // Form submission
  formCloth.onsubmit = (e) => {
    e.preventDefault();

    // Validate inputs
    if (!iClothName.value.trim()) {
      alert("Cloth name is required");
      iClothName.focus();
      return;
    }

    if (!iBrandName.value.trim()) {
      alert("Brand name is required");
      iBrandName.focus();
      return;
    }

    if (
      !iPrice.value ||
      isNaN(parseFloat(iPrice.value)) ||
      parseFloat(iPrice.value) < 0
    ) {
      alert("Please enter a valid price");
      iPrice.focus();
      return;
    }

    if (
      !iStock.value ||
      isNaN(parseInt(iStock.value)) ||
      parseInt(iStock.value) < 0
    ) {
      alert("Please enter a valid stock quantity");
      iStock.focus();
      return;
    }

    // Create form data
    const formData = new FormData();
    formData.append("name", iClothName.value.trim());
    formData.append("brand", iBrandName.value.trim());
    formData.append("price", parseFloat(iPrice.value));
    formData.append("stock", parseInt(iStock.value));

    if (iImage.files && iImage.files[0]) {
      formData.append("image", iImage.files[0]);
    }

    // Handle create or update based on selectedID
    if (selectedID === 0) {
      // Create new cloth
      axios
        .post("/api/cloth/store.php", formData)
        .then((res) => {
          if (!res.data.result) {
            alert(res.data.message);
            return;
          }
          clearForm();
          loadCloths();
        })
        .catch((error) => {
          console.error("Error adding cloth:", error);
          alert("Failed to add cloth. Please try again.");
        });
    } else {
      // Update existing cloth
      formData.append("id", selectedID);

      axios
        .post("/api/cloth/update.php", formData)
        .then((res) => {
          if (!res.data.result) {
            alert(res.data.message);
            return;
          }
          alert(res.data.message);
          clearForm();
          loadCloths();
        })
        .catch((error) => {
          console.error("Error updating cloth:", error);
          alert("Failed to update cloth. Please try again.");
        });
    }
  };
})();
