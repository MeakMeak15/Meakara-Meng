<?php
    require_once '../../bootstrap.php';
    
    // Create storage directories if they don't exist
    if(!is_dir('../../storage')){
        mkdir('../../storage');
    }
    if(!is_dir('../../storage/images')){
        mkdir('../../storage/images');
    }
    
    // Validate and process image upload
    $imageName = null;
    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0){
        $image = $_FILES['image'];
        
        // Validate image type
        if(!in_array($image['type'], ['image/jpeg', 'image/png'])){
            echo json_encode([
                'result' => false,
                'message' => 'Image must be jpg or png'
            ]);
            exit();
        }
        
        // Validate image size (max 2MB)
        if($image['size'] > 2 * 1048576){
            echo json_encode([
                'result' => false,
                'message' => 'Max file size 2MB'
            ]);
            exit();
        }
        
        // Generate unique filename and save image
        $path = pathinfo($image['name']);
        $imageName = uniqid() . '.' . $path['extension'];
        move_uploaded_file($image['tmp_name'], '../../storage/images/' . $imageName);
    }
    
    // Process product data
    $cloth = new Cloth();
    $cloth->name = $_POST['name'] ?? '';
    $cloth->brand = $_POST['brand'] ?? '';
    $cloth->price = floatval($_POST['price'] ?? 0);
    $cloth->stock = intval($_POST['stock'] ?? 0);
    $cloth->image = $imageName;
    
    // Store product in database
    echo $cloth->store();
?>