<?php
    require_once '../../bootstrap.php';
    
    $cloth = new Cloth();
    
    // Get search parameters if any
    $name = isset($_GET['name']) ? $_GET['name'] : null;
    $brand = isset($_GET['brand']) ? $_GET['brand'] : null;
    
    // Call the index method with search parameters
    echo $cloth->index($name, $brand);
?>