<?php
    require_once '../../bootstrap.php';
    
    // Validate ID parameter
    if(!isset($_GET['id']) || empty($_GET['id'])){
        echo json_encode([
            'result' => false,
            'message' => 'Product ID is required'
        ]);
        exit();
    }
    
    // Before deleting, get the product info to check for image
    $db = new Database();
    $result = $db->executeAssoc("SELECT image FROM products WHERE id = :id", ['id' => $_GET['id']]);
    
    // Delete the associated image if it exists
    if(!empty($result) && isset($result[0]['image']) && !empty($result[0]['image'])){
        $imagePath = '../../storage/images/' . $result[0]['image'];
        if(file_exists($imagePath)){
            unlink($imagePath);
        }
    }
    
    // Delete the product from database
    $cloth = new Cloth();
    $cloth->id = $_GET['id'];
    
    echo $cloth->destroy();
?>