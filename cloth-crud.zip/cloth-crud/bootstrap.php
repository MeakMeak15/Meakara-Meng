<?php 
    header('content-type: application/json');
    header('Access-Control-Allow-Origin: *');
    require_once __DIR__ . '/config/database.php';
    require_once __DIR__ . '/models/Database.php';
    require_once __DIR__ . '/models/Cloth.php';
?>