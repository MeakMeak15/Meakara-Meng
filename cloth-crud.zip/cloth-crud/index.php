<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fashion Store - Inventory Management</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="/assets/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="/assets/css/main.css">
</head>
<body>
<div class="main-container">
    <!-- Header Section -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <h1 class="mb-0" style="color: #2c3e50; font-weight: 600;">
                    <i class="fas fa-tshirt me-2"></i>Fashion Store
                </h1>
                <a href="" class="btn btn-info" target="_blank">
                    <i class="fas fa-user me-2"></i>About Me
                </a>
            </div>
        </div>
    </div>
    
    <div class="row g-4">
        <!-- Add Product Form (Left Side) -->
        <div class="col-lg-5">
            <div class="card">
                <div class="card-header">
                    <h5><i class="fas fa-plus-circle me-2"></i>Add New Product</h5>
                </div>
                <div class="card-body">
                    <form action="" method="POST" id="form-cloth">
                        <div class="mb-4">
                            <label class="form-label" for="cloth-name">
                                <i class="fas fa-tag me-2"></i>Product Name
                            </label>
                            <input type="text" class="form-control" id="cloth-name" placeholder="Enter product name" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label" for="brand-name">
                                <i class="fas fa-copyright me-2"></i>Brand Name
                            </label>
                            <input type="text" class="form-control" id="brand-name" placeholder="Enter brand name" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label" for="price">
                                <i class="fas fa-dollar-sign me-2"></i>Price
                            </label>
                            <input type="text" class="form-control" id="price" placeholder="Enter price" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label" for="stock">
                                <i class="fas fa-boxes me-2"></i>Stock Quantity
                            </label>
                            <input type="number" class="form-control" id="stock" placeholder="Enter stock quantity" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label" for="image">
                                <i class="fas fa-image me-2"></i>Product Image
                            </label>
                            <input type="file" class="form-control" id="image">
                        </div>
                        <button type="submit" id="btn-submit" class="btn btn-primary w-100">
                            <i class="fas fa-plus-circle me-2"></i>Add Product
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Product List (Right Side) -->
        <div class="col-lg-7">
            <div class="search-container">
                <div class="row align-items-center">
                    <div class="col">
                        <h5 class="mb-0" style="font-size: 1.5rem; color: #2c3e50;">
                            <i class="fas fa-list me-2"></i>Product Inventory
                        </h5>
                    </div>
                    <div class="col-auto">
                        <div class="search-input-group input-group">
                            <input type="text" id="search-text" class="form-control" placeholder="Search products...">
                            <button class="btn" type="button" id="button-search">
                                <i class="fas fa-search me-2"></i>Search
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="table-container">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th><i class="fas fa-tag me-2"></i>Product</th>
                                <th><i class="fas fa-copyright me-2"></i>Brand</th>
                                <th><i class="fas fa-dollar-sign me-2"></i>Price</th>
                                <th><i class="fas fa-boxes me-2"></i>Stock</th>
                                <th><i class="fas fa-chart-line me-2"></i>Status</th>
                                <th><i class="fas fa-cog me-2"></i>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="table-body">
                        </tbody>
                    </table>
                </div>

                <div class="text-start">
                    <div class="total-price" id="total-price">
                        <i class="fas fa-calculator me-2"></i>Total Inventory Value: $0
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="/assets/js/axios.min.js"></script>
<script src="/assets/js/bootstrap.min.js"></script>
<script src="/assets/js/script.js"></script>
</body>
</html>